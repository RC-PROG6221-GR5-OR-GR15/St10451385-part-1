
using System;
using System.Collections.Generic;

namespace CybersecurityChatbot
{
    public class ResponseHandler
    {
        private readonly Dictionary<string, string> _responses;

        public ResponseHandler()
        {
            _responses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                // General
                { "how are you",
                  "I'm running securely and efficiently, thank you! Ready to help you stay safe online. 😊" },

                { "what's your purpose",
                  "My purpose is to educate you about cybersecurity! I can help you with:\n" +
                  "  • Recognising phishing emails\n" +
                  "  • Creating strong passwords\n" +
                  "  • Identifying suspicious links\n" +
                  "  • Safe browsing habits" },

                { "what can i ask you",
                  "You can ask me about:\n" +
                  "  • Phishing\n  • Passwords\n  • Safe browsing\n" +
                  "  • Suspicious links\n  • Social engineering\n  • General cybersecurity tips" },

                // Phishing
                { "phishing",
                  "🎣 Phishing is when cybercriminals send fake emails/messages pretending to be legitimate organisations.\n\n" +
                  "  How to spot phishing:\n" +
                  "  ✅ Check the sender's email address carefully\n" +
                  "  ✅ Don't click unexpected links — hover first\n" +
                  "  ✅ Look for urgency tactics like 'Act Now!'\n" +
                  "  ✅ Verify requests via official channels\n" +
                  "  ✅ Poor spelling/grammar is a red flag" },

                // Passwords
                { "password",
                  "🔑 Strong Password Tips:\n" +
                  "  ✅ Use at least 12 characters\n" +
                  "  ✅ Mix uppercase, lowercase, numbers & symbols\n" +
                  "  ✅ Never reuse passwords across sites\n" +
                  "  ✅ Use a password manager\n" +
                  "  ✅ Enable Two-Factor Authentication (2FA)\n" +
                  "  ❌ Never use personal info like birthdays" },

                // Suspicious links
                { "suspicious link",
                  "🔗 How to handle suspicious links:\n" +
                  "  ✅ Hover over the link to see the real URL\n" +
                  "  ✅ Check for HTTPS (padlock icon)\n" +
                  "  ✅ Use a link checker like VirusTotal.com\n" +
                  "  ✅ Avoid shortened URLs from unknown sources\n" +
                  "  ❌ Never click links in unexpected emails/SMS" },

                // Safe browsing
                { "safe browsing",
                  "🌐 Safe Browsing Tips:\n" +
                  "  ✅ Keep your browser updated\n" +
                  "  ✅ Use a reputable antivirus\n" +
                  "  ✅ Only visit HTTPS websites\n" +
                  "  ✅ Avoid public Wi-Fi for sensitive tasks\n" +
                  "  ✅ Clear cookies and cache regularly\n" +
                  "  ✅ Use a VPN on public networks" },

                // Social engineering
                { "social engineering",
                  "🧠 Social Engineering is manipulating people into revealing confidential info.\n\n" +
                  "  Common tactics:\n" +
                  "  • Pretexting (fake scenarios)\n" +
                  "  • Baiting (free offers with malware)\n" +
                  "  • Tailgating (following into secure areas)\n" +
                  "  • Vishing (voice phishing calls)\n\n" +
                  "  Always verify identities before sharing information!" },

                // Malware
                { "malware",
                  "🦠 Malware includes viruses, ransomware, spyware & trojans.\n\n" +
                  "  Protection tips:\n" +
                  "  ✅ Install reputable antivirus software\n" +
                  "  ✅ Keep your OS and apps updated\n" +
                  "  ✅ Don't open unknown email attachments\n" +
                  "  ✅ Back up your data regularly\n" +
                  "  ✅ Avoid downloading software from untrusted sites" },

                // 2FA
                { "two factor",
                  "🔐 Two-Factor Authentication (2FA) adds an extra security layer.\n" +
                  "  Even if your password is stolen, attackers can't access your account.\n\n" +
                  "  Enable 2FA on:\n  • Email accounts\n  • Banking apps\n  • Social media\n  • Any sensitive service" },

                // Goodbye
                { "bye",    "👋 Stay safe online! Goodbye!" },
                { "exit",   "👋 Stay safe online! Goodbye!" },
                { "quit",   "👋 Stay safe online! Goodbye!" }
            };
        }

        public string GetResponse(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return null; // signals invalid input

            string lowerInput = input.ToLower().Trim();

            foreach (var key in _responses.Keys)
            {
                if (lowerInput.Contains(key))
                    return _responses[key];
            }

            return ""; // signals unrecognised input
        }

        public bool IsExitCommand(string input)
        {
            string lower = input.ToLower().Trim();
            return lower == "bye" || lower == "exit" || lower == "quit";
        }
    }
}
