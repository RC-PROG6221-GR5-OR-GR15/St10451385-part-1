
using System;

namespace CybersecurityChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            // Play voice greeting
            VoiceGreeting.Play("Resources/greeting.wav");

            // Display ASCII art header
            ConsoleUI.DisplayHeader();

            // Start the chatbot
            ChatBot bot = new ChatBot();
            bot.Start();
        }
    }
}
