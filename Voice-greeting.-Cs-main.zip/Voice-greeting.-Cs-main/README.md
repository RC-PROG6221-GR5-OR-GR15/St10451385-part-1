
using System;
using System.Media;
using System.IO;

namespace CybersecurityChatbot
{
    public class VoiceGreeting
    {
        public static void Play(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    SoundPlayer player = new SoundPlayer(filePath);
                    player.PlaySync(); // plays and waits until done
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("[INFO] Voice greeting file not found. Skipping audio.");
                    Console.ResetColor();
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[ERROR] Could not play audio: {ex.Message}");
                Console.ResetColor();
            }
        }
    }
}
