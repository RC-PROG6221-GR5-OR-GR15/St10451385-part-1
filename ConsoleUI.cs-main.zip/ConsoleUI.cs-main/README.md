
using System;
using System.Threading;

namespace CybersecurityChatbot
{
    public class ConsoleUI
    {
        public static void DisplayHeader()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(AsciiArt.GetLogo());
            Console.ResetColor();
            PrintDivider();
            TypeEffect("  Welcome to the Cybersecurity Awareness Chatbot!", ConsoleColor.Green);
            TypeEffect("  Protecting South African citizens one conversation at a time.", ConsoleColor.Green);
            PrintDivider();
            Console.WriteLine();
        }

        public static void PrintDivider()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("  " + new string('═', 55));
            Console.ResetColor();
        }

        public static void BotSpeak(string message)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("\n  🤖 Bot: ");
            Console.ResetColor();
            TypeEffect(message, ConsoleColor.White);
        }

        public static string UserInput(string prompt = "  👤 You: ")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n" + prompt);
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            string input = Console.ReadLine();
            Console.ResetColor();
            return input ?? "";
        }

        public static void TypeEffect(string text, ConsoleColor color, int delay = 30)
        {
            Console.ForegroundColor = color;
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
            Console.ResetColor();
        }

        public static void ShowError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"\n  ⚠️  {message}");
            Console.ResetColor();
        }
    }
}
