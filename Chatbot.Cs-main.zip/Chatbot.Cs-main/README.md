
using System;

namespace CybersecurityChatbot
{
    public class ChatBot
    {
        private string _userName;
        private readonly ResponseHandler _responseHandler;

        public ChatBot()
        {
            _responseHandler = new ResponseHandler();
        }

        public void Start()
        {
            GreetUser();
            RunConversationLoop();
        }

        private void GreetUser()
        {
            ConsoleUI.BotSpeak("Hello! I'm your Cybersecurity Awareness Assistant.");
            ConsoleUI.BotSpeak("Before we begin, may I know your name?");

            string name = "";
            while (string.IsNullOrWhiteSpace(name))
            {
                name = ConsoleUI.UserInput();
                if (string.IsNullOrWhiteSpace(name))
                {
                    ConsoleUI.ShowError("Invalid input. Please enter your name.");
                }
            }

            _userName = name.Trim();
            ConsoleUI.PrintDivider();
            ConsoleUI.BotSpeak($"Welcome, {_userName}! 🛡️ I'm here to help you stay safe online.");
            ConsoleUI.BotSpeak("You can ask me about: phishing, passwords, suspicious links,");
            ConsoleUI.BotSpeak("safe browsing, social engineering, malware, or type 'bye' to exit.");
            ConsoleUI.PrintDivider();
        }

        private void RunConversationLoop()
        {
            while (true)
            {
                string input = ConsoleUI.UserInput($"  👤 {_userName}: ");

                // Validate input
                if (string.IsNullOrWhiteSpace(input))
                {
                    ConsoleUI.ShowError("It looks like you didn't type anything. Could you rephrase?");
                    continue;
                }

                // Check for exit
                if (_responseHandler.IsExitCommand(input))
                {
                    ConsoleUI.PrintDivider();
                    ConsoleUI.BotSpeak($"Thank you for chatting, {_userName}! Stay safe out there. 🔐");
                    ConsoleUI.PrintDivider();
                    break;
                }

                // Get response
                string response = _responseHandler.GetResponse(input);

                if (response == null)
                {
                    // Empty/whitespace input (double-check)
                    ConsoleUI.ShowError("Invalid input detected. Please type a question.");
                }
                else if (response == "")
                {
                    // Unrecognised topic
                    ConsoleUI.BotSpeak($"I didn't quite understand that, {_userName}. Could you rephrase?");
                    ConsoleUI.BotSpeak("Try asking about: phishing, passwords, safe browsing, or suspicious links.");
                }
                else
                {
                    ConsoleUI.BotSpeak(response);
                }

                ConsoleUI.PrintDivider();
            }
        }
    }
}
